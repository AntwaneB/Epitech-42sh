/*
** my_explode.c for minilib in /home/buchse_a/Documents/Lib
**
** Made by Antoine Buchser
** Login   <buchse_a@epitech.net>
**
** Started on  Thu Mar 20 18:24:21 2014 Antoine Buchser
** Last update Thu Mar 20 18:34:46 2014 Antoine Buchser
*/

#include <stdlib.h>
#include "mini.h"

char	**my_explode(char *str)
{
  (void)str;
  return (NULL);
}
